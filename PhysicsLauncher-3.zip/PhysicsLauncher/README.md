# Fizik Launcher

Gerçek bir Android ana ekranı (launcher). İkonlar ve saat fizik nesnesi gibi davranır.

## Butonlar (üstte)
- **FİZİK: AÇIK/KAPALI** — Açınca her şey düşer, telefonu eğince kayar, sallayınca savrulur.
  Kapatınca her şey olduğu yerde DONAR ve hareket sensörü de tamamen kapanır.
- **SIFIRLA** — Her şeyi ilk ızgara düzenine döndürür, fiziği kapatır.
- **UYGULAMALAR** — Ana ekranda hangi uygulamaların olacağını seçersin (en fazla 24).

## Sürükleme
- Fizik KAPALI: ikonu tut, sürükle, bıraktığın yerde (havada bile) kalır. Sallanma yok.
- Fizik AÇIK: tuttuğun ikon parmağını hızına göre diğerlerini iter; hızla bırakırsan fırlar.

## Derleme (iki yol)

### A) Android Studio (bilgisayar)
1. Android Studio'yu aç, **Open** ile bu klasörü seç, Gradle eşitlemesini bekle.
2. **Build > Build APK(s)**. APK: `app/build/outputs/apk/debug/app-debug.apk`

### B) GitHub Actions (bilgisayara bir şey kurmadan)
1. Bu klasörü yeni bir GitHub deposuna yükle.
2. Depoda **Actions** sekmesi > **APK derle** çalışır (ya da *Run workflow*).
3. Bittiğinde çalışmanın altından **FizikLauncher-apk** dosyasını indir.

## Telefona kurma
1. APK'yı telefona gönder, aç, "bilinmeyen kaynaklardan yüklemeye" izin ver.
2. **Ana ekran tuşuna** bas > "Fizik Launcher" > **Her zaman**.
3. Eski launcher'a dönmek: Ayarlar > Uygulamalar > Varsayılan uygulamalar > Ana ekran uygulaması.
