package com.kanka.physicslauncher;

/** Fizik dünyasındaki tek bir nesne (ikon ya da saat). Hepsi daire olarak çarpışır. */
public final class Body {
    public float x, y, r;
    public float vx, vy;
    /** Parmakla tutulurken yumuşatılmış hız; bırakınca fırlatma hızı olarak kullanılır. */
    public float avx, avy;
    /** Parmakla tutulurken gitmesi gereken hedef nokta. */
    public float tx, ty;
    public boolean held;
    /** Sadece görsel eğilme (radyan). Fiziği etkilemez. */
    public float tilt;
    public Object tag;

    public Body(float x, float y, float r) {
        this.x = x;
        this.y = y;
        this.r = r;
        this.tx = x;
        this.ty = y;
    }

    float invMass() {
        return held ? 0f : 1f / (r * r);
    }
}
