package com.kanka.physicslauncher;

import java.util.ArrayList;

/**
 * Küçük, bağımlılıksız bir 2B daire fizik motoru.
 * - Sabit alt adımlar (1/120 sn), her adımda birkaç çözüm turu
 * - Daire-daire ve daire-duvar çarpışması, sürtünme, zıplama (restitution)
 * - Parmakla tutulan nesne "kinematik": hızıyla diğerlerini iter, bırakınca hızını korur
 */
public final class PhysicsWorld {
    public final ArrayList<Body> bodies = new ArrayList<>();

    public float left, top, right, bottom;
    /** Yerçekimi ivmesi, piksel/sn^2 (ekran koordinatları: y aşağı). */
    public float gx, gy;
    /** Bu hızın altındaki çarpışmalarda zıplama olmaz (yığılmanın titremesini önler). */
    public float restSpeed = 90f;

    private static final float SUBSTEP = 1f / 180f;
    private static final int ITER = 10;
    private static final float AIR_DRAG = 0.25f;
    private static final float BODY_E = 0.30f;
    private static final float WALL_E = 0.38f;
    private static final float MU = 0.12f;
    private static final float SLOP = 0.5f;
    private static final float CORRECT = 0.8f;
    private static final float WALL_FRICTION = 5f;
    private static final float SLEEP_V2 = 16f;

    public void step(float frameDt) {
        float dt = Math.min(Math.max(frameDt, 0f), 0.05f);
        if (dt <= 0f) return;
        int n = Math.max(1, (int) Math.ceil(dt / SUBSTEP));
        float h = dt / n;
        for (int i = 0; i < n; i++) sub(h);
    }

    private void sub(float h) {
        for (int i = 0, n = bodies.size(); i < n; i++) {
            Body b = bodies.get(i);
            if (b.held) {
                float dx = b.tx - b.x, dy = b.ty - b.y;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);
                float maxStep = b.r * 0.45f; // çok hızlı sürüklemede içinden geçmesin
                if (dist > maxStep) {
                    float s = maxStep / dist;
                    dx *= s;
                    dy *= s;
                }
                b.vx = dx / h;
                b.vy = dy / h;
                b.x += dx;
                b.y += dy;
                b.avx += (b.vx - b.avx) * 0.12f;
                b.avy += (b.vy - b.avy) * 0.12f;
            } else {
                b.vx += gx * h;
                b.vy += gy * h;
                float d = 1f - AIR_DRAG * h;
                b.vx *= d;
                b.vy *= d;
                b.x += b.vx * h;
                b.y += b.vy * h;
            }
        }
        float fr = Math.max(0f, 1f - WALL_FRICTION * h / ITER);
        for (int it = 0; it < ITER; it++) {
            resolveBodies();
            resolveWalls(fr);
        }
        for (int i = 0, n = bodies.size(); i < n; i++) {
            Body b = bodies.get(i);
            if (!b.held && b.vx * b.vx + b.vy * b.vy < SLEEP_V2) {
                b.vx = 0f;
                b.vy = 0f;
            }
        }
    }

    private void resolveBodies() {
        int n = bodies.size();
        for (int i = 0; i < n; i++) {
            Body a = bodies.get(i);
            for (int j = i + 1; j < n; j++) {
                Body b = bodies.get(j);
                float dx = b.x - a.x, dy = b.y - a.y;
                float minD = a.r + b.r;
                float d2 = dx * dx + dy * dy;
                if (d2 >= minD * minD) continue;
                float ia = a.invMass(), ib = b.invMass();
                float sum = ia + ib;
                if (sum == 0f) continue;
                float d = (float) Math.sqrt(d2);
                float nx, ny;
                if (d < 1e-4f) {
                    nx = 1f;
                    ny = 0f;
                    d = 0f;
                } else {
                    nx = dx / d;
                    ny = dy / d;
                }
                float pen = minD - d;
                float corr = Math.max(pen - SLOP, 0f) * CORRECT / sum;
                a.x -= nx * corr * ia;
                a.y -= ny * corr * ia;
                b.x += nx * corr * ib;
                b.y += ny * corr * ib;

                float rvx = b.vx - a.vx, rvy = b.vy - a.vy;
                float vn = rvx * nx + rvy * ny;
                if (vn < 0f) {
                    float e = (-vn > restSpeed) ? BODY_E : 0f;
                    float jn = -(1f + e) * vn / sum;
                    a.vx -= nx * jn * ia;
                    a.vy -= ny * jn * ia;
                    b.vx += nx * jn * ib;
                    b.vy += ny * jn * ib;

                    float tx = -ny, ty = nx;
                    float vt = rvx * tx + rvy * ty;
                    float jt = -vt / sum;
                    float maxJt = MU * jn;
                    if (jt > maxJt) jt = maxJt;
                    if (jt < -maxJt) jt = -maxJt;
                    a.vx -= tx * jt * ia;
                    a.vy -= ty * jt * ia;
                    b.vx += tx * jt * ib;
                    b.vy += ty * jt * ib;
                }
            }
        }
    }

    private void resolveWalls(float fr) {
        for (int i = 0, n = bodies.size(); i < n; i++) {
            Body b = bodies.get(i);
            if (b.x - b.r < left) {
                b.x = left + b.r;
                if (!b.held) {
                    if (b.vx < 0f) b.vx = (-b.vx > restSpeed) ? -b.vx * WALL_E : 0f;
                    b.vy *= fr;
                }
            } else if (b.x + b.r > right) {
                b.x = right - b.r;
                if (!b.held) {
                    if (b.vx > 0f) b.vx = (b.vx > restSpeed) ? -b.vx * WALL_E : 0f;
                    b.vy *= fr;
                }
            }
            if (b.y - b.r < top) {
                b.y = top + b.r;
                if (!b.held) {
                    if (b.vy < 0f) b.vy = (-b.vy > restSpeed) ? -b.vy * WALL_E : 0f;
                    b.vx *= fr;
                }
            } else if (b.y + b.r > bottom) {
                b.y = bottom - b.r;
                if (!b.held) {
                    if (b.vy > 0f) b.vy = (b.vy > restSpeed) ? -b.vy * WALL_E : 0f;
                    b.vx *= fr;
                }
            }
        }
    }

    public void clearVelocities() {
        for (Body b : bodies) {
            b.vx = 0f;
            b.vy = 0f;
            b.avx = 0f;
            b.avy = 0f;
            b.tilt = 0f;
        }
    }

    /** Parmağın altındaki en yakın nesne (merkeze göre normalize mesafe), yoksa null. */
    public Body hitTest(float px, float py) {
        Body best = null;
        float bestScore = Float.MAX_VALUE;
        for (Body b : bodies) {
            float dx = px - b.x, dy = py - b.y;
            float d2 = dx * dx + dy * dy;
            float lim = b.r * 1.05f;
            if (d2 <= lim * lim) {
                float score = d2 / (b.r * b.r);
                if (score < bestScore) {
                    bestScore = score;
                    best = b;
                }
            }
        }
        return best;
    }
}
