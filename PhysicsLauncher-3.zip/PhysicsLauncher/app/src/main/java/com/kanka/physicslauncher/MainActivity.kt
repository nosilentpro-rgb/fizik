package com.kanka.physicslauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.widget.Toast
import java.util.Locale

private class AppInfo(val key: String, val label: String, val ri: ResolveInfo)

@Suppress("DEPRECATION")
class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var home: HomeView
    private var allApps: List<AppInfo> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("home", MODE_PRIVATE)

        // Kenardan kenara (durum çubuğu / navigasyon çubuğu arkasına çizim)
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
        } else {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }

        home = HomeView(this, prefs)
        home.onLaunch = { key -> launchApp(key) }
        home.onPickApps = { showPicker() }
        home.setOnApplyWindowInsetsListener { _, insets ->
            val top: Int
            val bottom: Int
            if (Build.VERSION.SDK_INT >= 30) {
                val i = insets.getInsets(WindowInsets.Type.systemBars())
                top = i.top
                bottom = i.bottom
            } else {
                top = insets.systemWindowInsetTop
                bottom = insets.systemWindowInsetBottom
            }
            home.setInsets(top, bottom)
            insets
        }
        setContentView(home)
        home.requestApplyInsets()

        loadAllApps()
        applySelection()
    }

    override fun onResume() {
        super.onResume()
        home.onResume()
    }

    override fun onPause() {
        home.onPause()
        super.onPause()
    }

    // Ana ekranda geri tuşu hiçbir şey yapmaz.
    override fun onBackPressed() {}

    // ---------------------------------------------------------------------
    //  Uygulama listesi
    // ---------------------------------------------------------------------

    private fun loadAllApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        allApps = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                val cn = ComponentName(it.activityInfo.packageName, it.activityInfo.name)
                AppInfo(cn.flattenToString(), it.loadLabel(pm).toString(), it)
            }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    private fun defaultKeys(): List<String> {
        val wanted = listOf(
            "dialer", "contacts", "messag", "mms", "camera", "chrome", "photos", "gallery",
            "settings", "vending", "youtube", "whatsapp", "instagram", "maps", "gmail",
            "calendar", "deskclock", "calculator", "spotify", "telegram", "music", "files",
        )
        val out = LinkedHashSet<String>()
        for (w in wanted) {
            val m = allApps.firstOrNull { it.ri.activityInfo.packageName.contains(w, true) && it.key !in out }
            if (m != null) out.add(m.key)
            if (out.size >= DEFAULT_COUNT) break
        }
        for (a in allApps) {
            if (out.size >= DEFAULT_COUNT) break
            out.add(a.key)
        }
        return out.toList()
    }

    private fun currentOrder(): List<String> {
        val saved = prefs.getString("home_order", null)
        val keys = saved?.split("|")?.filter { it.isNotEmpty() } ?: defaultKeys()
        val existing = allApps.map { it.key }.toSet()
        return keys.filter { it in existing }.take(MAX_APPS)
    }

    private fun applySelection() {
        val pm = packageManager
        val byKey = allApps.associateBy { it.key }
        val list = currentOrder().mapNotNull { byKey[it] }.map {
            HomeApp(it.key, it.label, toBitmap(it.ri.loadIcon(pm)))
        }
        home.setApps(list)
    }

    private fun toBitmap(d: Drawable, size: Int = 192): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        d.setBounds(0, 0, size, size)
        d.draw(c)
        return bmp
    }

    private fun launchApp(key: String) {
        val cn = ComponentName.unflattenFromString(key) ?: return
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(cn)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Uygulama açılamadı", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------------
    //  Hangi uygulamalar ana ekranda olsun
    // ---------------------------------------------------------------------

    private fun showPicker() {
        loadAllApps() // yeni yüklenen / silinen uygulamalar için
        val chosen = LinkedHashSet<String>(currentOrder())
        val labels = allApps.map { it.label }.toTypedArray()
        val checked = BooleanArray(allApps.size) { allApps[it].key in chosen }

        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Ana ekran uygulamaları (en fazla $MAX_APPS)")
            .setMultiChoiceItems(labels, checked) { dialog, which, isChecked ->
                val key = allApps[which].key
                if (isChecked) {
                    if (chosen.size >= MAX_APPS) {
                        (dialog as AlertDialog).listView.setItemChecked(which, false)
                        Toast.makeText(this, "En fazla $MAX_APPS uygulama", Toast.LENGTH_SHORT).show()
                    } else {
                        chosen.add(key)
                    }
                } else {
                    chosen.remove(key)
                }
            }
            .setPositiveButton("Tamam") { _, _ ->
                prefs.edit().putString("home_order", chosen.joinToString("|")).apply()
                applySelection()
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    companion object {
        private const val MAX_APPS = 24
        private const val DEFAULT_COUNT = 16
    }
}
