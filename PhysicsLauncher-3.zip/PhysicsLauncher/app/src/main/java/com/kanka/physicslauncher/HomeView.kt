package com.kanka.physicslauncher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.text.TextPaint
import android.text.TextUtils
import android.text.format.DateFormat
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Ana ekranda görünecek bir uygulama. */
class HomeApp(val key: String, val label: String, val icon: Bitmap)

private class ItemTag(
    val key: String,
    val label: String,
    val icon: Bitmap?,
    val isClock: Boolean,
) {
    var shownLabel: String = label
}

/**
 * Tüm ana ekran tek bir özel View: ikonlar, saat ve butonlar burada çizilir.
 * Fizik KAPALIYKEN hiçbir şey hareket etmez, sensör bile dinlenmez.
 */
class HomeView(
    context: Context,
    private val prefs: SharedPreferences,
) : View(context), SensorEventListener {

    var onLaunch: ((String) -> Unit)? = null
    var onPickApps: (() -> Unit)? = null

    // ---- durum ----
    private val world = PhysicsWorld()
    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    private var apps: List<HomeApp> = emptyList()
    private var built = false
    private var dirty = false // kullanıcı bir şeyi oynattı mı (insets değişince düzen sıfırlanmasın)

    var physicsOn = false
        private set
    private var resumed = false
    private var insetTop = 0
    private var insetBottom = 0

    private var lastNs = 0L
    private var sx = 0f
    private var sy = 9.81f

    // ---- dokunma ----
    private val slop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()
    private var downX = 0f
    private var downY = 0f
    private var offX = 0f
    private var offY = 0f
    private var candidate: Body? = null
    private var heldBody: Body? = null
    private var dragging = false
    private var pressedBtn = -1

    // ---- sensör ----
    private val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accel: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private var sensorOn = false

    // ---- üst buton çubuğu ----
    private val btn = Array(3) { RectF() }

    // ---- saat ----
    private var timeStr = ""
    private var dateStr = ""
    private var clockStamp = -1L

    // ---- boyalar ----
    private val labelPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setShadowLayer(dp(3f), 0f, dp(1f), Color.argb(190, 0, 0, 0))
    }
    private val clockPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        setShadowLayer(dp(8f), 0f, dp(2f), Color.argb(130, 0, 0, 0))
    }
    private val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(225, 255, 255, 255)
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        letterSpacing = 0.08f
        setShadowLayer(dp(4f), 0f, dp(1f), Color.argb(150, 0, 0, 0))
    }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(
            0f, 0f, 1f,
            intArrayOf(Color.argb(120, 0, 0, 0), Color.argb(0, 0, 0, 0)),
            floatArrayOf(0.55f, 1f),
            Shader.TileMode.CLAMP,
        )
    }
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val pillFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val pillStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1f)
        color = Color.argb(70, 255, 255, 255)
    }
    private val btnText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.LEFT
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        letterSpacing = 0.06f
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dst = RectF()

    private val tick = object : Runnable {
        override fun run() {
            invalidate()
            postDelayed(this, 15000)
        }
    }

    // =====================================================================
    //  Dışarıdan çağrılanlar
    // =====================================================================

    fun setApps(newApps: List<HomeApp>) {
        if (built && newApps.map { it.key } == apps.map { it.key }) return
        if (built) savePositions()
        apps = newApps
        rebuild()
    }

    fun setInsets(top: Int, bottom: Int) {
        if (top == insetTop && bottom == insetBottom) return
        insetTop = top
        insetBottom = bottom
        layoutBar()
        updateBounds()
        if (!dirty) rebuild() else clampAll()
        invalidate()
    }

    fun onResume() {
        resumed = true
        updateSensor()
        lastNs = 0L
        invalidate()
    }

    fun onPause() {
        resumed = false
        updateSensor()
        savePositions()
    }

    // =====================================================================
    //  Fizik aç/kapat, sıfırla
    // =====================================================================

    fun setPhysics(on: Boolean) {
        if (on == physicsOn) return
        physicsOn = on
        if (on) {
            dirty = true
            lastNs = 0L
        } else {
            // Tam donma: hız, eğilme, her şey sıfır; nesneler olduğu yerde kalır.
            world.clearVelocities()
            savePositions()
        }
        updateSensor()
        performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        invalidate()
    }

    fun resetAll() {
        endDragInternal(applyVelocity = false)
        physicsOn = false
        updateSensor()
        val ed = prefs.edit()
        for (k in prefs.all.keys) if (k.startsWith("pos_")) ed.remove(k)
        ed.apply()
        dirty = false
        rebuild()
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        invalidate()
    }

    // =====================================================================
    //  Düzen
    // =====================================================================

    private fun layoutBar() {
        if (width == 0) return
        val margin = dp(14f)
        val gap = dp(8f)
        val bh = dp(42f)
        val top = insetTop + dp(8f)
        val bw = (width - 2 * margin - 2 * gap) / 3f
        for (i in 0..2) {
            val l = margin + i * (bw + gap)
            btn[i].set(l, top, l + bw, top + bh)
        }
    }

    private fun updateBounds() {
        if (width == 0 || height == 0) return
        world.left = 0f
        world.right = width.toFloat()
        world.top = btn[0].bottom + dp(8f)
        world.bottom = height - insetBottom - dp(6f)
        world.restSpeed = height * 0.04f
    }

    private fun clampAll() {
        for (b in world.bodies) {
            b.x = b.x.coerceIn(world.left + b.r, max(world.left + b.r, world.right - b.r))
            b.y = b.y.coerceIn(world.top + b.r, max(world.top + b.r, world.bottom - b.r))
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        layoutBar()
        updateBounds()
        rebuild()
    }

    private fun rebuild() {
        if (width == 0 || height == 0) return
        val w = width.toFloat()
        val h = height.toFloat()
        layoutBar()
        updateBounds()
        world.bodies.clear()
        heldBody = null
        candidate = null
        dragging = false

        val cols = 4
        val cellW = w / cols
        val clockR = cellW * 0.62f
        val topY = world.top + dp(4f)
        val gridTop = topY + clockR * 2f + dp(10f)
        val rows = max(1, ceil(apps.size / cols.toFloat()).toInt())
        val rowH = min(cellW, (world.bottom - gridTop) / rows)
        val r = min(cellW * 0.36f, rowH * 0.5f)

        // Saat
        val clock = Body(w / 2f, topY + clockR, clockR)
        clock.tag = ItemTag("__clock__", "", null, true)
        applySaved(clock, "__clock__", w, h)
        world.bodies.add(clock)

        // İkonlar
        labelPaint.textSize = r * 0.34f
        val maxLabelW = r * 1.9f
        apps.forEachIndexed { i, app ->
            val col = i % cols
            val row = i / cols
            val b = Body(cellW * (col + 0.5f), gridTop + rowH * (row + 0.5f), r)
            val tag = ItemTag(app.key, app.label, app.icon, false)
            tag.shownLabel = TextUtils.ellipsize(app.label, labelPaint, maxLabelW, TextUtils.TruncateAt.END).toString()
            b.tag = tag
            applySaved(b, app.key, w, h)
            world.bodies.add(b)
        }
        clampAll()
        built = true
    }

    private fun applySaved(b: Body, key: String, w: Float, h: Float) {
        val s = prefs.getString("pos_$key", null) ?: return
        val p = s.split(",")
        if (p.size != 2) return
        val nx = p[0].toFloatOrNull() ?: return
        val ny = p[1].toFloatOrNull() ?: return
        b.x = nx * w
        b.y = ny * h
        b.tx = b.x
        b.ty = b.y
    }

    private fun savePositions() {
        if (width == 0 || height == 0 || world.bodies.isEmpty()) return
        val ed = prefs.edit()
        for (b in world.bodies) {
            val t = b.tag as ItemTag
            ed.putString("pos_${t.key}", "${b.x / width},${b.y / height}")
        }
        ed.apply()
    }

    // =====================================================================
    //  Sensör (yerçekimi yönü)
    // =====================================================================

    private fun updateSensor() {
        val want = physicsOn && resumed
        if (want && !sensorOn) {
            accel?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
            sensorOn = true
        } else if (!want && sensorOn) {
            sm.unregisterListener(this)
            sensorOn = false
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        val a = 0.4f
        sx += (e.values[0].coerceIn(-45f, 45f) - sx) * a
        sy += (e.values[1].coerceIn(-45f, 45f) - sy) * a
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    // =====================================================================
    //  Çizim
    // =====================================================================

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        removeCallbacks(tick)
        postDelayed(tick, 15000)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(tick)
        if (sensorOn) {
            sm.unregisterListener(this)
            sensorOn = false
        }
        super.onDetachedFromWindow()
    }

    private fun refreshClock() {
        val now = System.currentTimeMillis()
        val stamp = now / 10000L
        if (stamp == clockStamp) return
        clockStamp = stamp
        val pattern = if (DateFormat.is24HourFormat(context)) "HH:mm" else "h:mm"
        val d = Date(now)
        timeStr = SimpleDateFormat(pattern, Locale.getDefault()).format(d)
        dateStr = SimpleDateFormat("d MMMM EEEE", Locale.getDefault()).format(d)
            .uppercase(Locale.getDefault())
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0f else ((now - lastNs) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastNs = now

        if (physicsOn && built) {
            val k = height * 0.16f // 1 m/s² = ekran yüksekliğinin %16'sı / sn²
            if (accel != null) {
                world.gx = -sx * k
                world.gy = sy * k
            } else {
                world.gx = 0f
                world.gy = 9.81f * k
            }
            world.step(dt)
        }

        refreshClock()

        // Önce tutulmayanlar, tutulan en üstte
        for (b in world.bodies) if (!b.held) drawBody(canvas, b)
        for (b in world.bodies) if (b.held) drawBody(canvas, b)

        drawBar(canvas)

        if (physicsOn || heldBody != null) postInvalidateOnAnimation() else lastNs = 0L
    }

    private fun drawBody(c: Canvas, b: Body) {
        val tag = b.tag as ItemTag

        // Hafif eğilme: sadece fizik açıkken, hıza bağlı; durunca düzelir.
        val speedX = if (b.held) b.avx else b.vx
        val targetTilt = if (physicsOn) (speedX / (height * 2f)).coerceIn(-0.3f, 0.3f) else 0f
        b.tilt += (targetTilt - b.tilt) * 0.25f

        val lift = if (b.held) 1.1f else 1f
        c.save()
        c.translate(b.x, b.y)
        c.rotate(Math.toDegrees(b.tilt.toDouble()).toFloat())
        c.scale(lift, lift)

        if (tag.isClock) {
            clockPaint.textSize = b.r * 0.72f
            c.drawText(timeStr, 0f, clockPaint.textSize * 0.34f, clockPaint)
            datePaint.textSize = b.r * 0.17f
            c.drawText(dateStr, 0f, clockPaint.textSize * 0.34f + datePaint.textSize * 1.9f, datePaint)
        } else {
            val r = b.r
            // yumuşak gölge
            c.save()
            c.translate(0f, r * (if (b.held) 0.32f else 0.18f))
            val sr = r * (if (b.held) 1.3f else 1.12f)
            c.scale(sr, sr)
            c.drawCircle(0f, 0f, 1f, shadowPaint)
            c.restore()

            val s = r * 1.45f
            val cy = -r * 0.22f
            dst.set(-s / 2f, cy - s / 2f, s / 2f, cy + s / 2f)
            tag.icon?.let { c.drawBitmap(it, null, dst, bmpPaint) }

            labelPaint.textSize = r * 0.34f
            c.drawText(tag.shownLabel, 0f, r * 0.95f, labelPaint)
        }
        c.restore()
    }

    private fun drawBar(c: Canvas) {
        val physText = if (physicsOn) "FİZİK: AÇIK" else "FİZİK: KAPALI"
        val dot = if (physicsOn) Color.rgb(57, 217, 138) else Color.rgb(255, 92, 92)
        drawPill(c, 0, physText, dot)
        drawPill(c, 1, "SIFIRLA", null)
        drawPill(c, 2, "UYGULAMALAR", null)
    }

    private fun drawPill(c: Canvas, i: Int, text: String, dotColor: Int?) {
        val rc = btn[i]
        val rad = rc.height() / 2f
        pillFill.color = if (pressedBtn == i) Color.argb(190, 40, 44, 66) else Color.argb(120, 12, 14, 26)
        c.drawRoundRect(rc, rad, rad, pillFill)
        c.drawRoundRect(rc, rad, rad, pillStroke)

        btnText.textSize = dp(11f)
        val dotSpace = if (dotColor != null) dp(14f) else 0f
        val avail = rc.width() - dp(22f) - dotSpace
        val tw = btnText.measureText(text)
        if (tw > avail) btnText.textSize = btnText.textSize * avail / tw
        val tw2 = btnText.measureText(text)
        val startX = rc.centerX() - (tw2 + dotSpace) / 2f
        val baseY = rc.centerY() - (btnText.descent() + btnText.ascent()) / 2f
        if (dotColor != null) {
            dotPaint.color = dotColor
            c.drawCircle(startX + dp(4f), rc.centerY(), dp(4f), dotPaint)
        }
        c.drawText(text, startX + dotSpace, baseY, btnText)
    }

    // =====================================================================
    //  Dokunma
    // =====================================================================

    private fun hitButton(x: Float, y: Float): Int {
        for (i in 0..2) if (btn[i].contains(x, y)) return i
        return -1
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                downY = e.y
                dragging = false
                pressedBtn = hitButton(e.x, e.y)
                candidate = if (pressedBtn >= 0) null else world.hitTest(e.x, e.y)
                invalidate()
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (pressedBtn >= 0) {
                    if (hitButton(e.x, e.y) != pressedBtn) {
                        pressedBtn = -1
                        invalidate()
                    }
                    return true
                }
                val c = candidate ?: return true
                if (!dragging && hypot(e.x - downX, e.y - downY) > slop) startDrag(c)
                if (dragging) moveDrag(e.x, e.y)
                return true
            }

            MotionEvent.ACTION_UP -> {
                val pb = pressedBtn
                pressedBtn = -1
                if (pb >= 0) {
                    if (hitButton(e.x, e.y) == pb) onButton(pb)
                } else if (dragging) {
                    endDragInternal(applyVelocity = true)
                } else {
                    val t = candidate?.tag as? ItemTag
                    if (t != null && !t.isClock) onLaunch?.invoke(t.key)
                }
                candidate = null
                invalidate()
                return true
            }

            MotionEvent.ACTION_CANCEL -> {
                pressedBtn = -1
                endDragInternal(applyVelocity = true)
                candidate = null
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    private fun onButton(i: Int) {
        when (i) {
            0 -> setPhysics(!physicsOn)
            1 -> resetAll()
            2 -> onPickApps?.invoke()
        }
    }

    private fun startDrag(b: Body) {
        dragging = true
        dirty = true
        heldBody = b
        b.held = true
        // Parmağı bastığın noktada tutarsın; nesne parmağa zıplamaz.
        offX = b.x - downX
        offY = b.y - downY
        b.tx = b.x
        b.ty = b.y
        b.avx = 0f
        b.avy = 0f
        performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    private fun moveDrag(px: Float, py: Float) {
        val b = heldBody ?: return
        val minX = world.left + b.r
        val maxX = max(minX, world.right - b.r)
        val minY = world.top + b.r
        val maxY = max(minY, world.bottom - b.r)
        val nx = (px + offX).coerceIn(minX, maxX)
        val ny = (py + offY).coerceIn(minY, maxY)
        if (physicsOn) {
            // Fizik açık: hedefe doğru gider, hızıyla diğerlerini iter, bırakınca hızı kalır.
            b.tx = nx
            b.ty = ny
        } else {
            // Fizik kapalı: tam parmağın altında; bırakınca olduğu yerde kalır.
            b.x = nx
            b.y = ny
            b.tx = nx
            b.ty = ny
        }
        invalidate()
    }

    private fun endDragInternal(applyVelocity: Boolean) {
        val b = heldBody ?: run {
            dragging = false
            return
        }
        b.held = false
        if (physicsOn && applyVelocity) {
            val maxV = height * 4f
            val sp = hypot(b.avx, b.avy)
            val k = if (sp > maxV) maxV / sp else 1f
            b.vx = b.avx * k
            b.vy = b.avy * k
        } else {
            b.vx = 0f
            b.vy = 0f
            b.avx = 0f
            b.avy = 0f
            b.tilt = 0f
        }
        heldBody = null
        dragging = false
        if (!physicsOn) savePositions()
        invalidate()
    }
}
